<?php

class Usuario extends Model {
	public static $_table = 'usuario';
}

?>
