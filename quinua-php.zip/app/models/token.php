<?php

class Token extends Model {
	public static $_table = 'tokens';
}

?>
