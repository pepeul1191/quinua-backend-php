<?php

class Estacion extends Model {
	public static $_table = 'inve_estacion';
}

?>
