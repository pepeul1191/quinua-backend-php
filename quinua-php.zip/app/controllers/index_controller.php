<?php

class IndexController extends Controller
{
    public static function index()
    {
        echo "Error : URL Vacía";
    }
}

?>
